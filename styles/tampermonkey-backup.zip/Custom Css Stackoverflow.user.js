// ==UserScript==
// @name        Custom Css Stackoverflow
// @namespace   style-loader
// @version     1
// @resource    FILE_CSS file:///home/near/styles/dist/stackoverflow/style.min.css
// @author      Near Huscarl
// @include     https://stackoverflow.com/*
// @grant       GM_getResourceText
// @grant       GM_addStyle
// @run-at      document-start
// ==/UserScript==

let cssText = GM_getResourceText ('FILE_CSS');
GM_addStyle (cssText);