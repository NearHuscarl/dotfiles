// ==UserScript==
// @name        Custom Css Instant Markdown D
// @namespace   style-loader
// @version     1
// @resource    FILE_CSS file:///home/near/styles/dist/instant-markdown-d/style.min.css
// @author      Near Huscarl
// @include     http://localhost:8090/
// @grant       GM_getResourceText
// @grant       GM_addStyle
// @run-at      document-start
// ==/UserScript==

let cssText = GM_getResourceText ('FILE_CSS');
GM_addStyle (cssText);