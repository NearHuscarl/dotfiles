// ==UserScript==
// @name        Custom Css Facebook
// @namespace   style-loader
// @version     1
// @resource    FILE_CSS file:///home/near/styles/dist/facebook/style.min.css
// @author      Near Huscarl
// @include     https://www.facebook.com/*
// @grant       GM_getResourceText
// @grant       GM_addStyle
// @run-at      document-start
// ==/UserScript==

let cssText = GM_getResourceText ('FILE_CSS');
GM_addStyle (cssText);