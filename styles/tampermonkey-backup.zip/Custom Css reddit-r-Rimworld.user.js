// ==UserScript==
// @name        Custom Css reddit/r/Rimworld
// @namespace   style-loader
// @version     1
// @resource    FILE_CSS file:///home/near/styles/dist/reddit-rimworld/style.min.css
// @author      Near Huscarl
// @include     https://www.reddit.com/r/Rimworld/*
// @grant       GM_getResourceText
// @grant       GM_addStyle
// @run-at      document-start
// ==/UserScript==

let cssText = GM_getResourceText ('FILE_CSS');
GM_addStyle (cssText);