// ==UserScript==
// @name        Custom Css reddit/r/Python
// @namespace   style-loader
// @version     1
// @resource    FILE_CSS file:///home/near/styles/dist/reddit-python/style.min.css
// @author      Near Huscarl
// @include     https://www.reddit.com/r/Python/*
// @grant       GM_getResourceText
// @grant       GM_addStyle
// @run-at      document-start
// ==/UserScript==

let cssText = GM_getResourceText ('FILE_CSS');
GM_addStyle (cssText);