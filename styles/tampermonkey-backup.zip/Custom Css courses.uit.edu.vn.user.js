// ==UserScript==
// @name        Custom Css courses.uit.edu.vn
// @namespace   style-loader
// @version     1
// @resource    file:///home/near/css/variables.css
// @resource    FILE_CSS file:///home/near/styles/dist/uit.courses/style.min.css
// @author      Near Huscarl
// @include     https://courses.uit.edu.vn/*
// @grant       GM_getResourceText
// @grant       GM_addStyle
// @run-at      document-start
// ==/UserScript==

let cssText = GM_getResourceText ('FILE_CSS');
GM_addStyle (cssText);