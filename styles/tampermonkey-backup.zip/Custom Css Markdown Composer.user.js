// ==UserScript==
// @name        Custom Css Markdown Composer
// @namespace   style-loader
// @version     1
// @resource    FILE_CSS file:///home/near/styles/dist/markdown-composer/style.min.css
// @author      Near Huscarl
// @include     /http:\/\/\[::1\]:[0-9]{5}\//
// @grant       GM_getResourceText
// @grant       GM_addStyle
// @run-at      document-start
// ==/UserScript==

let cssText = GM_getResourceText ('FILE_CSS');
GM_addStyle (cssText);