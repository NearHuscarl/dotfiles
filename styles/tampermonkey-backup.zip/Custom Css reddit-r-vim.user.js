// ==UserScript==
// @name        Custom Css reddit/r/vim
// @namespace   style-loader
// @version     1
// @resource    FILE_CSS file:///home/near/styles/dist/reddit-vim/style.min.css
// @author      Near Huscarl
// @include     https://www.reddit.com/r/vim/*
// @grant       GM_getResourceText
// @grant       GM_addStyle
// @run-at      document-start
// ==/UserScript==

let cssText = GM_getResourceText ('FILE_CSS');
GM_addStyle (cssText);