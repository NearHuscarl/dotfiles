// ==UserScript==
// @name        Custom Css ctsv.uit.edu.vn
// @namespace   style-loader
// @version     1
// @resource    FILE_CSS file:///home/near/styles/dist/uit-ctsv/style.min.css
// @author      Near Huscarl
// @include     http://ctsv.uit.edu.vn/*
// @grant       GM_getResourceText
// @grant       GM_addStyle
// @run-at      document-start
// ==/UserScript==

let cssText = GM_getResourceText ('FILE_CSS');
GM_addStyle (cssText);