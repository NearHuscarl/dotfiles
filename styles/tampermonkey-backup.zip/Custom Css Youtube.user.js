// ==UserScript==
// @name        Custom Css Youtube
// @namespace   style-loader
// @version     1
// @resource    FILE_CSS file:///home/near/styles/dist/youtube/style.min.css
// @author      Near Huscarl
// @include     https://www.youtube.com/*
// @grant       GM_getResourceText
// @grant       GM_addStyle
// @run-at      document-start
// ==/UserScript==

let cssText = GM_getResourceText ('FILE_CSS');
GM_addStyle (cssText);