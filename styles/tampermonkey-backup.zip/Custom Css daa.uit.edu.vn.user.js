// ==UserScript==
// @name        Custom Css daa.uit.edu.vn
// @namespace   style-loader
// @version     1
// @resource    FILE_CSS file:///home/near/styles/dist/uit.daa/style.min.css
// @author      Near Huscarl
// @include     https://daa.uit.edu.vn/*
// @grant       GM_getResourceText
// @grant       GM_addStyle
// @run-at      document-end
// ==/UserScript==

let cssText = GM_getResourceText ('FILE_CSS');
GM_addStyle (cssText);