// ==UserScript==
// @name        Custom Css ArchLinux Wiki
// @namespace   style-loader
// @version     1
// @resource    FILE_CSS file:///home/near/styles/dist/archlinux/style.min.css
// @author      Near Huscarl
// @include     https://wiki.archlinux.org/*
// @grant       GM_getResourceText
// @grant       GM_addStyle
// @run-at      document-start
// ==/UserScript==

let cssText = GM_getResourceText ('FILE_CSS');
console.log('csstext: ' + cssText);
GM_addStyle (cssText);